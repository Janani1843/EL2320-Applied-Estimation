% This function calcultes the weights for each particle based on the
% observation likelihood
%           S_bar(t)            4XM
%           outlier             1Xn
%           Psi(t)              1XnXM
% Outputs: 
%           S_bar(t)            4XM
function S_bar = weight(S_bar, Psi, outlier)

    % YOUR IMPLEMENTATION
    %psi_sq = squeeze(Psi);
    psi_sq = Psi(1,find(~outlier),:);
    w = prod(psi_sq,2);
    w = w/sum(w);
    S_bar(4,:) = w;
    
  
end
