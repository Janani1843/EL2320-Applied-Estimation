% This function is the implementation of the measurement model.
% The bearing should be in the interval [-pi,pi)
% Inputs:
%           S(t)                           4XM
%           j                              1X1
% Outputs:  
%           h                              2XM
function z_j = observation_model(S, j)

    global map % map including the coordinates of all landmarks | shape 2Xn for n landmarks
    global M % number of particles

    % YOUR IMPLEMENTATION
    % the observation model in EKF is modified for M number of particles
    %z_j = zeros(2,M);
    %z_angle = zeros(1,M);
    %remap = zeros(2,M);
    remap = repmat(map(:,j),1,M);
    S_temp = remap - S(1:2,:);
    for i = 1:size(remap,2)
        z_j(1,i) = norm(S_temp(:,i));
        z_angle(i) = atan2((remap(2,i)-S(2,i)),(remap(1,i)-S(1,i)));
    end
    z_j(2,:)= z_angle - S(3,:);
    z_j(2,:) = mod(z_j(2,:)+pi,2*pi)- pi;
   

end