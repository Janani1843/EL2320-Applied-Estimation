% This function performs the ML data association
%           S_bar(t)                 4XM
%           z(t)                     2Xn
%           association_ground_truth 1Xn | ground truth landmark ID for
%           every measurement
% Outputs: 
%           outlier                  1Xn
%           Psi(t)                   1XnXM
function [outlier, Psi, c] = associate(S_bar, z, association_ground_truth)
    if nargin < 3
        association_ground_truth = [];
    end

    global DATA_ASSOCIATION % wheter to perform data association or use ground truth
    global lambda_psi % threshold on average likelihood for outlier detection
    global Q % covariance matrix of the measurement model
    global M % number of particles
    global N % number of landmarks
    global landmark_ids % unique landmark IDs
    
    
    % YOUR IMPLEMENTATION
    n = size(z,2);
   
    
    %z_bar = zeros(2,M,N);
    %outlier = zeros(1,n);
    %Psi = zeros(n ,M);
    
%psi_temp=zeros(M,N);
    %c = zeros(n,M);
    
    
    
    for j = 1:N
        z_bar(:,:,j) = observation_model(S_bar,j);
    end
    
    %z_bar = permute(z_bar,[1,3,2]);
    norm = det(2*pi*Q).^(-1/2);
    %Q_changed = repmat(diag(inv(Q)),[1 N M]);
    
    for i = 1:n
        for j = 1:M
            for k = 1:N
                inn(:,j,k) = z(:,i) - z_bar(:,j,k);
                inn(2,j,k) = mod(inn(2,j,k)+pi,2*pi)-pi;
                power = (inn(:,j,k)'/Q)*inn(:,j,k);
                psi_temp(i,j,k) = norm*exp(-0.5*power);
                
            end
            pos = find(psi_temp(i,j,:) == max(psi_temp(i,j,:)));
            c(i,j) = pos(1);
            Psi(i,j) = psi_temp(i,j,c(i,j));
        end  
        outlier(i) = mean(Psi(i,:))<=lambda_psi;
    end
   Psi = reshape(Psi,[1 n M]);
   c = reshape(c,[1 n M]);
end