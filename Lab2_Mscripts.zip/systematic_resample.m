% This function performs systematic re-sampling
% Inputs:   
%           S_bar(t):       4XM
% Outputs:
%           S(t):           4XM
function S = systematic_resample(S_bar)
	
    global M % number of particles 
    
    r = rand()/M;
    S = zeros(size(S_bar));
    for i = 1:M
        CDF(i) = sum(S_bar(4,1:i));
    end
    
    for m=1:M
        k =find(CDF>=r+(m-1)/M,1);
        %if ~isempty(k)
        S(:,m) = S_bar(:,k);
        %end
        
        S(4,m) = 1/M;
    end
    

end