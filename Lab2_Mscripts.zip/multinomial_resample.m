% This function performs multinomial re-sampling
% Inputs:   
%           S_bar(t):       4XM
% Outputs:
%           S(t):           4XM
function S = multinomial_resample(S_bar)

    global M % number of particles
    
    % YOUR IMPLEMENTATION
    S = zeros(size(S_bar));
    CDF = zeros(1,M);
    
    for i = 1:M
        CDF(i) = sum(S_bar(4,1:i));
    end
    
    for j = 1:M
        r = rand();
        k = find(CDF>=r,1);
        %if ~isempty(k) %very important
            %S(:,j) = S_bar(:,k);
        %end
        S(:,j) = S_bar(:,k);
        %S(:,j) = S_bar(:,find(CDF>=r,1,'first'));
        S(4,j) = 1/M;
    end

end
