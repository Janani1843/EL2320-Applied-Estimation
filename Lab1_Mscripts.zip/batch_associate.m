% This function performs the maximum likelihood association and outlier detection.
% Note that the bearing error lies in the interval [-pi,pi)
%           mu_bar(t)           3X1
%           sigma_bar(t)        3X3
%           z(t)                2Xn
% Outputs: 
%           c(t)                1Xn
%           outlier             1Xn
%           nu_bar(t)           2nX1
%           H_bar(t)            2nX3
function [c, outlier, nu_bar, H_bar] = batch_associate(mu_bar, sigma_bar, z)
        
        global Q % measurement covariance matrix | 1X1
        global lambda_m % outlier detection threshold on mahalanobis distance | 1X1
        global map % map | 2Xn
        n1 = length(z);
        n2 = length(map);
        %H = zeros(2,3,n2); S = zeros(2, 2, n2); nu = zeros(2, n2); chi = zeros(1,n2);
        %D = zeros(1,n2); z_hat = zeros(2,n2); c = zeros(1,n1); outlier = zeros(1,n1);
        for i = 1: size(z,2)
            for j = 1 : size(map,2)
                z_hat=observation_model(mu_bar,j);
                H(:,:,j)=jacobian_observation_model(mu_bar,j,z_hat);
                S(:,:,j)=H(:,:,j)*sigma_bar*H(:,:,j)'+Q;
                nu(:,j)=z(:,i)-z_hat;
                nu(2,j)=mod(nu(2,j)+pi,2*pi)-pi;
                D(j)=(nu(:,j)'/S(:,:,j))*nu(:,j);
                chi(j)=det(2*pi*S(:,:,j)).^(-1/2)*exp(-1/2*D(j));
            end
            
            [maxValue maxIndex] = max(chi);
            c(i) = maxIndex;
            outlier(i) = (D(c(i)) >= lambda_m);
            nu_bar(:,i) = nu(:,c(i));
            H_bar(:,:,i) = H(:,:,c(i));
        end
        
        temp = [];
        for k = 1:size(H_bar,3)
            temp = [temp; H_bar(:,:,k)];
        end
        
        H_bar = temp;
            
end