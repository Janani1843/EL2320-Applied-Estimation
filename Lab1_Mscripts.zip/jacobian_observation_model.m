% This function is the implementation of the jacobian measurement model
% required for the update of the covariance function after incorporating
% the measurements
% Inputs:
%           x(t)        3X1
%           j           1X1 which landmark (map column)
%           z_j         2X1
% Outputs:  
%           H           2X3
function H = jacobian_observation_model(x, j, z_j)

    global map % map | 2Xn for n landmarks
    H1 = (x(1)-map(1,j))/z_j(1);
    H2 = (x(2)-map(2,j))/z_j(1);
    H3 = -(x(2)-map(2,j))/((z_j(1))^2);
    H4 = (x(1)-map(1,j))/((z_j(1))^2);
    H = [H1 H2 0; H3 H4 -1];
end
